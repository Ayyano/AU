import { DeepSeekStream, StreamingTextResponse } from "ai"

// Ensure the API key is loaded from the environment variable
const apiKey = process.env.DEEPSEEK_API_KEY

if (!apiKey) {
  throw new Error("DEEPSEEK_API_KEY is not set in the environment variables")
}

export const runtime = "edge"

const systemPrompt = `You are an AI assistant specializing in Pakistani event budgeting. 
You can provide advice on various events including weddings (mehndi, baraat, walima), birthday parties, corporate events, religious celebrations, engagement parties, graduation parties, and family reunions. 
Provide cost estimates in Pakistani Rupees (PKR) for various aspects such as venue, catering, decor, attire, and entertainment. 
Tailor your advice to Pakistani customs, local price ranges, and cultural norms. Be prepared to suggest budget allocations and cost-saving tips for events of different scales (simple, moderate, lavish).`

export async function POST(req: Request) {
  const { messages } = await req.json()

  const response = await fetch("https://api.deepseek.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "deepseek-chat",
      messages: [{ role: "system", content: systemPrompt }, ...messages],
      stream: true,
    }),
  })

  const stream = DeepSeekStream(response)

  return new StreamingTextResponse(stream)
}

