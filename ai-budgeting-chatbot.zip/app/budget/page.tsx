"use client"

import { useChat } from "ai/react"
import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, Gift, Briefcase, ChurchIcon as Mosque } from "lucide-react"

const eventTypes = [
  { name: "Wedding", icon: <Calendar className="w-6 h-6" /> },
  { name: "Corporate", icon: <Briefcase className="w-6 h-6" /> },
  { name: "Birthday", icon: <Gift className="w-6 h-6" /> },
  { name: "Religious", icon: <Mosque className="w-6 h-6" /> },
]

export default function BudgetPage() {
  const { messages, input, handleInputChange, handleSubmit } = useChat()
  const [eventType, setEventType] = useState<string | null>(null)
  const [totalBudget, setTotalBudget] = useState(100000) // Starting at 100,000 PKR
  const [eventScale, setEventScale] = useState<"simple" | "moderate" | "lavish">("moderate")
  const [guestCount, setGuestCount] = useState(100) // Default guest count

  const handleEventTypeSelect = (type: string) => {
    setEventType(type)
    const prompt = `I want to create a budget for a ${eventScale} Pakistani ${type} event with a total budget of ${totalBudget.toLocaleString()} PKR for approximately ${guestCount} guests. Please provide a detailed breakdown of costs and suggestions for allocating the budget, considering local customs, venues, and catering options.`

    handleSubmit({ preventDefault: () => {} } as any, {
      options: {
        body: {
          messages: [{ role: "user", content: prompt }],
        },
      },
    })
  }

  const handleTotalBudgetChange = (value: number[]) => {
    setTotalBudget(value[0])
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-pakistan-beige to-pakistan-brown p-4"
    >
      <Card className="w-full max-w-2xl futuristic-card">
        <CardHeader>
          <CardTitle className="text-pakistan-green">Pakistani Event Budgeting AI</CardTitle>
        </CardHeader>
        <CardContent>
          {eventType === null ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-2 gap-4">
                {eventTypes.map((type) => (
                  <motion.div key={type.name} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button
                      onClick={() => handleEventTypeSelect(type.name)}
                      className="w-full flex items-center justify-center space-x-2"
                    >
                      {type.icon}
                      <span>{type.name}</span>
                    </Button>
                  </motion.div>
                ))}
              </div>
              <div className="space-y-2">
                <label htmlFor="budget-slider" className="text-sm font-medium text-pakistan-green">
                  Total Budget: {totalBudget.toLocaleString()} PKR
                </label>
                <Slider
                  id="budget-slider"
                  min={0}
                  max={10000000}
                  step={10000}
                  value={[totalBudget]}
                  onValueChange={handleTotalBudgetChange}
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="guest-count" className="text-sm font-medium text-pakistan-green">
                  Approximate Guest Count: {guestCount}
                </label>
                <Slider
                  id="guest-count"
                  min={10}
                  max={1000}
                  step={10}
                  value={[guestCount]}
                  onValueChange={(value) => setGuestCount(value[0])}
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="event-scale" className="text-sm font-medium text-pakistan-green">
                  Event Scale
                </label>
                <Select onValueChange={(value: "simple" | "moderate" | "lavish") => setEventScale(value)}>
                  <SelectTrigger id="event-scale">
                    <SelectValue placeholder="Select event scale" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="simple">Simple</SelectItem>
                    <SelectItem value="moderate">Moderate</SelectItem>
                    <SelectItem value="lavish">Lavish</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </motion.div>
          ) : (
            <ScrollArea className="h-[400px] w-full pr-4">
              {messages.map((m, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className={`mb-4 ${m.role === "user" ? "text-right" : "text-left"}`}
                >
                  <span
                    className={`inline-block p-2 rounded-lg ${m.role === "user" ? "bg-pakistan-green text-white" : "bg-white text-pakistan-green"}`}
                  >
                    {m.content}
                  </span>
                </motion.div>
              ))}
            </ScrollArea>
          )}
        </CardContent>
        <CardFooter>
          <form onSubmit={handleSubmit} className="flex w-full space-x-2">
            <Input
              value={input}
              onChange={handleInputChange}
              placeholder="Ask about your budget..."
              className="flex-grow modern-input"
            />
            <Button type="submit" className="bg-pakistan-green text-white">
              Send
            </Button>
          </form>
        </CardFooter>
      </Card>
    </motion.div>
  )
}

