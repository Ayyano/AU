import "./globals.css"
import { Inter } from "next/font/google"
import Link from "next/link"
import { motion } from "framer-motion"
import type React from "react" // Added import for React

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Pakistani Event Budgeting AI",
  description: "Plan your Pakistani events with AI-powered budgeting assistance",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <motion.nav
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="bg-pakistan-green p-4"
        >
          <div className="container mx-auto flex justify-between items-center">
            <Link href="/" className="text-white text-xl font-bold">
              Event Budgeting AI
            </Link>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Link href="/budget" className="text-white hover:text-pakistan-beige">
                Start Budgeting
              </Link>
            </motion.div>
          </div>
        </motion.nav>
        {children}
      </body>
    </html>
  )
}

