"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Calendar, Gift, Briefcase, ChurchIcon as Mosque } from "lucide-react"

export default function LandingPage() {
  const eventTypes = [
    { name: "Wedding", icon: <Calendar className="w-6 h-6" /> },
    { name: "Corporate", icon: <Briefcase className="w-6 h-6" /> },
    { name: "Birthday", icon: <Gift className="w-6 h-6" /> },
    { name: "Religious", icon: <Mosque className="w-6 h-6" /> },
  ]

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-pakistan-beige to-pakistan-brown text-pakistan-green">
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center relative z-10"
      >
        <div className="mb-8">
          <motion.svg
            width="100"
            height="100"
            viewBox="0 0 100 100"
            initial={{ rotate: 0 }}
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
          >
            <circle cx="50" cy="50" r="45" fill="none" stroke="#01411C" strokeWidth="2" />
            <path d="M50 5 L50 95 M5 50 L95 50" stroke="#01411C" strokeWidth="2" />
            <text x="50" y="55" fontSize="20" fill="#01411C" textAnchor="middle" dominantBaseline="middle">
              EB AI
            </text>
          </motion.svg>
        </div>
        <h1 className="text-5xl font-bold mb-6">Pakistani Event Budgeting AI</h1>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="text-2xl mb-8"
        >
          Plan your perfect event with our AI-powered budgeting tool
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.8 }}
          className="space-y-4"
        >
          <div className="flex justify-center space-x-8 mb-8">
            {eventTypes.map((type, index) => (
              <motion.div key={type.name} whileHover={{ scale: 1.1 }} className="flex flex-col items-center">
                <div className="w-16 h-16 rounded-full bg-pakistan-green flex items-center justify-center text-white mb-2">
                  {type.icon}
                </div>
                <span>{type.name}</span>
              </motion.div>
            ))}
          </div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Link href="/budget">
              <Button className="bg-pakistan-green hover:bg-pakistan-brown text-white font-bold py-3 px-6 rounded-full text-lg transition duration-300 ease-in-out transform hover:scale-105">
                Start Planning Your Event
              </Button>
            </Link>
          </motion.div>
        </motion.div>
      </motion.div>

      <footer className="mt-16 text-pakistan-green">
        <p>© 2025 Pakistani Event Budgeting AI. All rights reserved.</p>
      </footer>
    </div>
  )
}

